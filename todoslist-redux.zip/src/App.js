// import logo from "./logo.svg";
import "./App.css";
import LoginForm from "./pages/LoginPage/LoginForm";
import Todo from "./pages/TodosPage/Todo";
import TestMui from "./pages/Mui/TestMui";
import {
  BrowserRouter,
  BrowserRouter as Router,
  Route,
  Routes,
} from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<LoginForm />} />
        <Route exact path="/todo" element={<Todo />} />
        <Route exact path="/mui" element={<TestMui />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
