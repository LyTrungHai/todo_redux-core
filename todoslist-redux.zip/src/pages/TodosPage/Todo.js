import React from "react";

import { useSelector } from "react-redux";
export default function Todo() {
  const person = useSelector((state) => state.loginReducer);
  console.log(person);

  return (
    <div>
      <h1>hello</h1>
    </div>
  );
}
