const INITIAL_STATE = {};

const loginReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case "LOGIN":
      return { ...state, userLogin: action.infoLogin };
    default:
      return state;
  }
};

export default loginReducer;
